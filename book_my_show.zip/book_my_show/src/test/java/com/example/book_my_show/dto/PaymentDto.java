package com.example.book_my_show.dto;

public class PaymentDto {

}
